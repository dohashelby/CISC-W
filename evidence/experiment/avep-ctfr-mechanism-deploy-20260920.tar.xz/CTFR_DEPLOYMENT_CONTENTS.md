# CTFR deployment bundle contents

The deployment archive contains the frozen inputs for the first CTFR mechanism
gate.  It does not contain result data or credentials.

This bundle exercises shared, PCFR-route, and CTFR-shadow behavior.  It does
not invoke `ctfr-full` retirement and cannot by itself support a claim that
validated retirement preserves benign adaptation.  That claim requires the
separate Stage D harness and tenant-local baseline described in the protocol.
It also does not contain the mixed-batch worker-attribution or deterministic
decision-replay tests required for the stronger end-to-end noninterference
claim.

- design and claim-boundary documents: `CTFR_*.md`;
- cumulative source patches: paper instrumentation, causal ablation, PCFR, and
  CTFR;
- `prepare_ctfr_source.sh`, which applies those patches idempotently to the
  pinned commit and runs remote syntax/unit checks through the pinned venv;
- `run_ctfr_mechanism.sh`, which reuses the audited server lifecycle and runs
  the predeclared gate/performance schedule;
- the fail-closed CTFR analyzer and its unit tests;
- the authenticated CTFR gateway, bounded probe, base analyzer, and frozen base
  driver required transitively by the harness.

The bundle must be hashed locally, copied to the retained EBS volume, hashed
again remotely, and extracted only if both values match.  Credentials remain
generated on the instance with mode `0600` and are excluded from archives meant
for publication.
