# CTFR experiment protocol

## Objective

Evaluate whether context-tagged feedback retirement removes the confirmed
post-request victim effect, whether its protection is stronger than policy-only
routing, and whether validated retirement preserves useful benign adaptation.

All confirmatory thresholds, source hashes, model revisions, orders, and
workloads are frozen before the first confirmatory request.  Pilot data may
select an observable same-policy and benign-drift workload but is never reused
as confirmation.

## Fixed environment

- vLLM commit `4fe9e6f6e5647a159c9e65e4f3bf33dec5d12e1c`;
- the model and draft revisions from factorial-confirmatory v2;
- one NVIDIA L40S worker behind the localhost authenticated gateway;
- fresh process and reset controller for every arm;
- requests, gateway audit events, trusted internal request IDs, worker markers,
  and phase labels joined one-to-one;
- model revisions, feature contract, canonical effective policy, and
  verification configuration fixed process-wide;
- attacker work fully drained before post-attack victim measurement.

## Stage 0: implementation invariants

Before performance trials, use deterministic unit and integration tests to
show:

1. the gateway, not the client, binds principal identity;
2. client-supplied request IDs and identity-like headers cannot select another
   principal's bank;
3. attacker and victim observations remain correctly attributed even when
   their requests share a GPU batch;
4. committed coefficients, refit metadata, version, and influence credits
   remain exactly invariant under unretired feedback while only the selected
   shadow statistics change;
5. retirement is invoked only after the harness has drained every admitted
   request at the declared single-worker quiescent barrier; and
6. one eligible retirement attempt produces the declared final coefficients,
   version, credits, refit metadata, and cleared shadows.

A deterministic victim replay additionally compares the complete verification-
budget sequence element-by-element with and without an attacker shadow.  Until
that optional stronger test passes, the claim is limited to serialized
committed-state invariance rather than end-to-end decision noninterference.

Version pinning, stale-candidate squash under concurrent promotion, crash
atomicity, and dynamic eviction are explicitly out of scope for this prototype.

Any invariant failure stops GPU performance experiments.

## Stage A: cross-policy mechanism and mitigation gate

Reuse the frozen `allowed_token_ids=[279]` intervention and the existing phase
shape:

```text
1,024 victim warm-up
4 x 128 victim pre windows
4,096 attacker or placebo intervention requests
queue drain
8 x 128 victim post windows
```

Detailed telemetry arms:

1. `placebo_shared`;
2. `attack_shared`;
3. `attack_route` (the PCFR routing mechanism check);
4. `placebo_ctfr-shadow`;
5. `attack_ctfr-shadow`.

This stage verifies that the known effect is still reachable, checks the PCFR
state-routing mechanism, and tests CTFR committed-state invariance.  Because
the gate has no placebo-route arm, it makes no PCFR performance-mitigation
claim.  Any PCFR or CTFR performance statement requires paired placebo arms and
the eight-block schedule below; the initial gate runs alone are not performance
replicates.

## Stage B: same-policy discrimination

This stage prevents CTFR from collapsing into PCFR under a new name.  A pilot
selects a low-acceptance prompt/workload corpus without changing the canonical
effective policy.  Confirmation logs must establish equality of:

- target and draft model revisions;
- canonical sampling-policy fingerprint;
- estimator feature-contract version;
- temperature, verification configuration, and output constraints; and
- all controller context except authenticated principal and payload.

Confirmatory arms are `placebo_shared`, `attack_shared`, `placebo_route`,
`attack_route`, `placebo_ctfr-shadow`, `attack_ctfr-shadow`, and matched
`ctfr-full` arms.  PCFR is expected to share state because the policy
fingerprint is identical; CTFR-shadow is expected to isolate unretired attacker
feedback.  CTFR-full separately records whether the candidate is ineligible,
squashed, or retired within the predeclared influence bounds.

If a reproducible API-level same-policy attack cannot be found before the
predeclared pilot budget expires, this stage is reported as unavailable.  It
must not be simulated by relabeling a cross-policy attack as same-policy.

## Stage C: slow-drip attack

Using the same-policy attack fixed in Stage B, insert one poison request after
each declared batch of benign updates across multiple retirement attempts.  The
final attack request must finish and the queue must drain before victim
measurement.  Compare `shared`, `ctfr-shadow`, and `ctfr-full` against matched
placebo sequences.  CTFR-full is the primary treatment because it tests whether
many small candidates can pass retirement and accumulate drift.

The primary mechanism endpoint remains committed-state invariance.  The
performance endpoint is secondary because a sufficiently weak slow drip may
not create a measurable shared-mode effect within the fixed cost horizon.

## Stage D: benign adaptation retirement

Two distinct authenticated principals, both assigned frozen benign workloads
by the experiment, encounter the same workload shift.  The validator observes
identity and update geometry, not benignness or independence.  Compare:

- `shared` as the adaptive ceiling for this configuration;
- `drop` as the non-adaptive floor;
- `tenant-local` as the strongest simple adaptive-isolation baseline;
- `ctfr-shadow` as a no-promotion control; and
- `ctfr-full` with the predeclared retirement rule.

The sequence is:

```text
baseline regime
-> simultaneous declared workload shift for benign principals A and B
-> independent shadow accumulation
-> exactly one validator decision at a quiescent retirement barrier
-> post-retirement evaluation on held-out requests
```

Run eight fresh-process blocks per arm, with exactly one retirement attempt per
CTFR-full block.  The fixed 161-point validation grid and held-out evaluation
requests are distinct.  Retirement success, delay, squash rate, calibration
loss, verification budget, throughput, and latency are recorded.  This stage
is required before claiming that CTFR preserves adaptation.  A paper-level
benefit claim additionally requires a declared advantage over tenant-local,
such as faster recovery or higher held-out utility from corroborating benign
principals.

The tenant-local and CTFR arms receive identical total and per-principal
observation budgets.  Held-out outcomes are reported separately for principals
A and B before aggregation.  This makes the intended comparison explicit:
whether corroborated cross-principal evidence adds useful adaptation beyond
two isolated adaptive estimators, not whether CTFR merely saw more traffic.

## Stage E: assumption and overhead tests

### Sybil boundary

With the fixed two-principal validator, compare one attacker identity with two
attacker-controlled identities.  One identity must fail quorum.  The two-
credential case is a negative control that may retire and therefore documents,
rather than hides, the quorum-capture limitation.  Also test attacker plus
benign principal with directionally disagreeing candidates; it must squash.

Dynamic-cardinality, TTL, and eviction experiments are deferred because the
prototype hard-codes two banks.  They remain explicit production limitations.

### No-attack overhead

Compare `shared` and `ctfr-full` under identical benign stationary traffic.
Report throughput, p50/p95 latency, GPU memory, host memory, and shadow-manager
CPU time.

### Origin-binding robustness

Attempt victim-prefix request IDs, conflicting identity-like headers, and
missing credentials.  Confirm that the gateway overwrites external IDs and
that every accepted request joins one-to-one with the intended worker bank.

## Replication and estimands

Security-performance comparisons use eight fresh temporal blocks.  Arm order
is frozen in a balanced schedule.  The independent unit is the complete block,
not individual requests.

For outcome `Y`, the primary mitigation interaction is:

```text
I_b = [Y(attack, CTFR) - Y(placebo, CTFR)]
      - [Y(attack, shared) - Y(placebo, shared)]
```

Positive throughput `I_b` means CTFR specifically removes attack harm.  Each
post window is normalized by that process's four pre windows, then the fixed
eight-window mean is used.  Confidence intervals resample complete blocks with
a fixed seed.

## Scope-preserving stop rules

- Stage B starts only after Stage A invariants pass.
- Stage C starts only if the same-policy pilot yields a frozen workload.
- Stage D uses a separate pilot and confirmatory cohort.
- Stage E may use cheap CPU tests where GPU behavior is irrelevant.
- Every AWS run has a shutdown deadline and partial-archive trap.
- Failed structural validation invalidates the arm; it is not retried silently.
