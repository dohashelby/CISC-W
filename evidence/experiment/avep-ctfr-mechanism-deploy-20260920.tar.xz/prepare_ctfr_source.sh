#!/usr/bin/env bash
set -Eeuo pipefail

readonly WORK_DIR="/home/ubuntu/avep"
readonly REPO_DIR="${WORK_DIR}/vllm"
readonly VENV_DIR="${REPO_DIR}/.venv"
readonly PINNED_SHA="4fe9e6f6e5647a159c9e65e4f3bf33dec5d12e1c"

apply_once() {
    local patch_path="$1"
    if git -C "${REPO_DIR}" apply --check "${patch_path}"; then
        git -C "${REPO_DIR}" apply "${patch_path}"
        printf 'applied=%s\n' "$(basename "${patch_path}")"
        return
    fi
    if git -C "${REPO_DIR}" apply --reverse --check "${patch_path}"; then
        printf 'already_applied=%s\n' "$(basename "${patch_path}")"
        return
    fi
    printf 'Patch is neither cleanly applicable nor already applied: %s\n' \
        "${patch_path}" >&2
    return 1
}

[[ "$(git -C "${REPO_DIR}" rev-parse HEAD)" == "${PINNED_SHA}" ]] || {
    printf 'Pinned vLLM commit is not checked out.\n' >&2
    exit 1
}
[[ -x "${VENV_DIR}/bin/python" ]] || {
    printf 'Pinned virtual-environment Python is unavailable.\n' >&2
    exit 1
}

readonly -a STACK_FILES=(
    vllm/v1/worker/gpu/model_runner.py
    vllm/v1/worker/gpu/spec_decode/acceptance_estimator.py
    vllm/v1/worker/gpu/spec_decode/speculator.py
    vllm/v1/worker/gpu_worker.py
)
readonly BASE_STACK="f8df4ab6bbcb6de84b4550bcadbc35bab893ab85c038930d765baecd613e1107"
readonly PAPER_STACK="58fa58f2c63d3ff65e475d76f5e688484bc8cfa1b15eb88117a9e1d6f28d814d"
readonly CAUSAL_STACK="914044ebf8f76fc56995f35c13ae9691344c78b838d1a0a3780adb8f4390c5b8"
readonly PCFR_STACK="64eead73f0da37dbebc572d9b845b48f02a4c1dee8655d2da0bcf7c1fe60cd9a"
readonly CTFR_STACK="44e0239ad70e7f2b8d9736ca1dfaedb5a2fb309b222e70e4b5c7bee44141e0cf"

stack_digest() {
    (
        cd "${REPO_DIR}"
        sha256sum "${STACK_FILES[@]}"
    ) | sha256sum | cut -d' ' -f1
}

current_stack="$(stack_digest)"
case "${current_stack}" in
    "${BASE_STACK}")
        apply_once "${WORK_DIR}/avep_paper_instrumentation.patch"
        apply_once "${WORK_DIR}/avep_causal_ablation.patch"
        apply_once "${WORK_DIR}/avep_pcfr_mitigation.patch"
        apply_once "${WORK_DIR}/avep_ctfr_mitigation.patch"
        ;;
    "${PAPER_STACK}")
        apply_once "${WORK_DIR}/avep_causal_ablation.patch"
        apply_once "${WORK_DIR}/avep_pcfr_mitigation.patch"
        apply_once "${WORK_DIR}/avep_ctfr_mitigation.patch"
        ;;
    "${CAUSAL_STACK}")
        apply_once "${WORK_DIR}/avep_pcfr_mitigation.patch"
        apply_once "${WORK_DIR}/avep_ctfr_mitigation.patch"
        ;;
    "${PCFR_STACK}")
        apply_once "${WORK_DIR}/avep_ctfr_mitigation.patch"
        ;;
    "${CTFR_STACK}")
        printf 'already_applied=complete_ctfr_stack\n'
        ;;
    *)
        printf 'Refusing an unknown or partially modified patch stack: %s\n' \
            "${current_stack}" >&2
        exit 1
        ;;
esac

[[ "$(stack_digest)" == "${CTFR_STACK}" ]] || {
    printf 'Final CTFR source digest does not match the frozen stack.\n' >&2
    exit 1
}

git -C "${REPO_DIR}" diff --check
"${VENV_DIR}/bin/python" -m py_compile \
    "${REPO_DIR}/vllm/v1/worker/gpu/model_runner.py" \
    "${REPO_DIR}/vllm/v1/worker/gpu/spec_decode/acceptance_estimator.py" \
    "${REPO_DIR}/vllm/v1/worker/gpu/spec_decode/speculator.py" \
    "${REPO_DIR}/vllm/v1/worker/gpu_worker.py" \
    "${WORK_DIR}/ctfr_gateway.py" \
    "${WORK_DIR}/analyze_ctfr_mechanism.py" \
    "${WORK_DIR}/test_analyze_ctfr_mechanism.py"
(
    cd "${WORK_DIR}"
    "${VENV_DIR}/bin/python" -m unittest -v \
        test_analyze_ctfr_mechanism.py
)

sha256sum \
    "${WORK_DIR}/avep_paper_instrumentation.patch" \
    "${WORK_DIR}/avep_causal_ablation.patch" \
    "${WORK_DIR}/avep_pcfr_mitigation.patch" \
    "${WORK_DIR}/avep_ctfr_mitigation.patch" \
    "${WORK_DIR}/ctfr_gateway.py" \
    "${WORK_DIR}/analyze_ctfr_mechanism.py" \
    "${WORK_DIR}/test_analyze_ctfr_mechanism.py" \
    "${WORK_DIR}/run_ctfr_mechanism.sh"
