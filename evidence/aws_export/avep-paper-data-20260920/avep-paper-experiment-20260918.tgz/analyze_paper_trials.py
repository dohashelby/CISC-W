#!/usr/bin/env python
"""Analyze fresh-process AVEP paper trials without pseudo-replication."""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
import re
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any


METRICS = {
    "throughput": "aggregate_output_tokens_per_second",
    "latency_p50": "latency_ms_p50",
    "latency_p95": "latency_ms_p95",
}
PHASE_PATTERN = re.compile(r"===== AVEP_PHASE (\S+)")
BUDGET_PATTERN = re.compile(r"AVEP_BUDGET\s+(\{.*\})")


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text())


def ratio(numerator: Any, denominator: Any) -> float | None:
    if numerator is None or denominator in (None, 0):
        return None
    value = float(numerator) / float(denominator)
    return value if math.isfinite(value) else None


def mean(values: list[float]) -> float | None:
    return statistics.fmean(values) if values else None


def bootstrap_mean_ci(
    values: list[float], *, samples: int = 20_000, seed: int = 20260918
) -> dict[str, float | int | None]:
    if not values:
        return {"n": 0, "mean": None, "ci95_low": None, "ci95_high": None}
    rng = random.Random(seed)
    means = []
    for _ in range(samples):
        draw = [values[rng.randrange(len(values))] for _ in values]
        means.append(statistics.fmean(draw))
    means.sort()
    return {
        "n": len(values),
        "mean": statistics.fmean(values),
        "ci95_low": means[int(samples * 0.025)],
        "ci95_high": means[min(int(samples * 0.975), samples - 1)],
    }


def phase_summary(run_dir: Path, phase: str) -> dict[str, Any]:
    return load_json(run_dir / f"{phase}.json")["summary"]


def estimator_state(run_dir: Path, phase: str) -> dict[str, Any] | None:
    path = run_dir / f"state_{phase}.json"
    if not path.exists():
        return None
    payload = load_json(path)
    results = payload.get("results") or []
    if not results or not isinstance(results[0], dict):
        return None
    return results[0]


def exact_output_match(left: Path, right: Path) -> float | None:
    if not left.exists() or not right.exists():
        return None
    left_records = load_json(left).get("records", [])
    right_records = load_json(right).get("records", [])
    count = min(len(left_records), len(right_records))
    if not count:
        return None
    matches = 0
    comparable = 0
    for index in range(count):
        left_ids = left_records[index].get("token_ids") or []
        right_ids = right_records[index].get("token_ids") or []
        if not left_ids or not right_ids:
            continue
        comparable += 1
        matches += left_ids == right_ids
    return matches / comparable if comparable else None


def budget_ratios(server_log: Path) -> dict[str, float]:
    observations: dict[str, list[float]] = defaultdict(list)
    phase: str | None = None
    for line in server_log.read_text(errors="replace").splitlines():
        phase_match = PHASE_PATTERN.search(line)
        if phase_match:
            marker = phase_match.group(1)
            phase = marker.removesuffix("_begin") if marker.endswith("_begin") else None
            continue
        budget_match = BUDGET_PATTERN.search(line)
        if phase is None or not budget_match:
            continue
        row = json.loads(budget_match.group(1))
        if row["max_draft_budget"]:
            observations[phase].append(
                row["draft_budget"] / row["max_draft_budget"]
            )
    return {
        phase_name: statistics.fmean(values)
        for phase_name, values in observations.items()
        if values
    }


def summarize_run(run_dir: Path) -> dict[str, Any]:
    metadata = load_json(run_dir / "metadata.json")
    baseline = phase_summary(run_dir, "baseline")
    post_paths = sorted(run_dir.glob("post_[0-9][0-9].json"))
    post_summaries = [load_json(path)["summary"] for path in post_paths]
    row: dict[str, Any] = {
        "run": run_dir.name,
        "pair_id": metadata.get("pair_id"),
        "arm": metadata["arm"],
        "adaptive": metadata["adaptive"],
        "telemetry": metadata["telemetry"],
        "poison_token_id": metadata.get("poison_token_id"),
        "post_windows": len(post_summaries),
        "failed_requests": baseline["failed"]
        + sum(summary["failed"] for summary in post_summaries),
    }
    for short_name, key in METRICS.items():
        baseline_value = baseline.get(key)
        ratios = [ratio(summary.get(key), baseline_value) for summary in post_summaries]
        finite = [value for value in ratios if value is not None]
        row[f"post1_{short_name}_ratio"] = finite[0] if finite else None
        row[f"post_mean_{short_name}_ratio"] = mean(finite)
        if short_name == "throughput":
            row[f"post_worst_{short_name}_ratio"] = min(finite) if finite else None
        else:
            row[f"post_worst_{short_name}_ratio"] = max(finite) if finite else None

    before = estimator_state(run_dir, "baseline")
    after = estimator_state(run_dir, "intervention")
    if before and before.get("available") and after and after.get("available"):
        row["slope_before"] = before["slope"]
        row["slope_after"] = after["slope"]
        row["intercept0_before"] = before["intercepts"][0]
        row["intercept0_after"] = after["intercepts"][0]
    reset = estimator_state(run_dir, "reset")
    if reset and reset.get("available"):
        row["slope_after_reset"] = reset["slope"]
        row["intercept0_after_reset"] = reset["intercepts"][0]
    if metadata["telemetry"]:
        budgets = budget_ratios(run_dir / "server.log")
        row["baseline_budget_ratio"] = budgets.get("baseline")
        row["intervention_budget_ratio"] = budgets.get("intervention")
        row["post1_budget_ratio"] = budgets.get("post_01")
    row["baseline_post1_exact_token_match"] = exact_output_match(
        run_dir / "baseline.json", run_dir / "post_01.json"
    )
    return row


def paired_effects(rows: list[dict[str, Any]]) -> dict[str, Any]:
    pairs: dict[str, dict[str, dict[str, Any]]] = defaultdict(dict)
    for row in rows:
        if row["pair_id"] is not None:
            pairs[str(row["pair_id"])][row["arm"]] = row

    effects: dict[str, list[float]] = defaultdict(list)
    complete_pairs = 0
    for arms in pairs.values():
        if "attack" not in arms or "placebo" not in arms:
            continue
        complete_pairs += 1
        attack = arms["attack"]
        placebo = arms["placebo"]
        for metric in METRICS:
            key = f"post_mean_{metric}_ratio"
            if attack.get(key) is not None and placebo.get(key) is not None:
                effects[metric].append(attack[key] - placebo[key])
    return {
        "complete_pairs": complete_pairs,
        "attack_minus_placebo": {
            metric: bootstrap_mean_ci(values)
            for metric, values in sorted(effects.items())
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--result-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--csv-output", type=Path, required=True)
    args = parser.parse_args()

    run_dirs = sorted(
        path
        for path in args.result_root.iterdir()
        if path.is_dir()
        and (path / "metadata.json").exists()
        and (path / "COMPLETE").exists()
    )
    rows = [summarize_run(run_dir) for run_dir in run_dirs]
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[row["arm"]].append(row)

    assessment = {
        "scope": (
            "Fresh server processes are the experimental units. Per-request "
            "observations are not treated as independent replicates."
        ),
        "run_count": len(rows),
        "arm_counts": {arm: len(group) for arm, group in sorted(grouped.items())},
        "paired_analysis": paired_effects(rows),
        "performance_arm_summaries": {
            arm: {
                metric: bootstrap_mean_ci(
                    [
                        row[f"post_mean_{metric}_ratio"]
                        for row in group
                        if row.get(f"post_mean_{metric}_ratio") is not None
                    ]
                )
                for metric in METRICS
            }
            for arm, all_rows in sorted(grouped.items())
            if (group := [row for row in all_rows if not row["telemetry"]])
        },
        "runs": rows,
    }
    args.output.write_text(json.dumps(assessment, indent=2, sort_keys=True) + "\n")

    fieldnames = sorted({key for row in rows for key in row})
    with args.csv_output.open("w", newline="") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(assessment, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
