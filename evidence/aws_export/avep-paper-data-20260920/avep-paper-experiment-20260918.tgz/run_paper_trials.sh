#!/usr/bin/env bash
set -Eeuo pipefail

readonly WORK_DIR="${HOME}/avep"
readonly REPO_DIR="${WORK_DIR}/vllm"
readonly VENV_DIR="${REPO_DIR}/.venv"
readonly RESULT_ROOT="${WORK_DIR}/paper_results"
readonly API_KEY="local-research-only"
readonly POST_WINDOWS="${POST_WINDOWS:-6}"
readonly PAIR_COUNT="${PAIR_COUNT:-6}"
readonly RESET_REPS="${RESET_REPS:-3}"
readonly ADAPTIVE_OFF_REPS="${ADAPTIVE_OFF_REPS:-3}"

mkdir -p "${RESULT_ROOT}"
export PATH="${VENV_DIR}/bin:${PATH}"

server_pid=""
current_log=""

stop_server() {
    if [[ -n "${server_pid}" ]] && kill -0 "${server_pid}" 2>/dev/null; then
        kill "${server_pid}"
        for _ in $(seq 1 60); do
            kill -0 "${server_pid}" 2>/dev/null || break
            sleep 1
        done
        kill -9 "${server_pid}" 2>/dev/null || true
    fi
    server_pid=""
}

trap stop_server EXIT

mark_phase() {
    local phase="$1"
    printf '===== AVEP_PHASE %s %s =====\n' \
        "${phase}" "$(date --iso-8601=ns)" >> "${current_log}"
}

start_server() {
    local run_dir="$1"
    local adaptive="$2"
    local telemetry="$3"
    local detailed_metrics="$4"
    stop_server
    current_log="${run_dir}/server.log"

    export HF_HUB_DISABLE_TELEMETRY=1
    export VLLM_ADAPTIVE_VERIFICATION_PROFILE_CONTEXT_LEN=4096
    export VLLM_HOST_IP=127.0.0.1
    export VLLM_USE_V2_MODEL_RUNNER=1
    export VLLM_SERVER_DEV_MODE=1
    if [[ "${telemetry}" == "true" ]]; then
        export VLLM_AVEP_TELEMETRY=1
        export VLLM_AVEP_TELEMETRY_BUDGET_EVERY=10
    else
        unset VLLM_AVEP_TELEMETRY || true
        unset VLLM_AVEP_TELEMETRY_BUDGET_EVERY || true
    fi

    local spec_config
    spec_config="$(printf '%s' "{
        \"method\":\"dflash\",
        \"model\":\"z-lab/Qwen3-4B-DFlash-b16\",
        \"revision\":\"b74e3a329c4d963783143b1e970d95b002be72bd\",
        \"code_revision\":\"b74e3a329c4d963783143b1e970d95b002be72bd\",
        \"attention_backend\":\"TRITON_ATTN\",
        \"num_speculative_tokens\":4,
        \"max_model_len\":4096,
        \"enable_adaptive_verification\":${adaptive}
    }")"

    local server_args=(
        serve Qwen/Qwen3-4B
        --revision 1cfa9a7208912126459214e8b04321603b3df60c
        --host 127.0.0.1
        --port 8000
        --api-key "${API_KEY}"
        --dtype bfloat16
        --trust-remote-code
        --max-model-len 4096
        --max-num-seqs 64
        --max-num-batched-tokens 4096
        --gpu-memory-utilization 0.80
        --no-enable-prefix-caching
        --attention-backend TRITON_ATTN
        --compilation-config '{"cudagraph_mode":"FULL_AND_PIECEWISE"}'
        --speculative-config "${spec_config}"
    )
    if [[ "${detailed_metrics}" == "true" ]]; then
        server_args+=(
            --enable-per-request-metrics
            --per-request-spec-decode-metrics detailed
        )
    fi

    cd "${REPO_DIR}"
    nohup "${VENV_DIR}/bin/vllm" "${server_args[@]}" \
        > "${current_log}" 2>&1 &
    server_pid="$!"
    printf '%s\n' "${server_pid}" > "${run_dir}/server.pid"

    for _ in $(seq 1 180); do
        if ! kill -0 "${server_pid}" 2>/dev/null; then
            tail -200 "${current_log}"
            return 1
        fi
        if curl --fail --silent \
            -H "Authorization: Bearer ${API_KEY}" \
            http://127.0.0.1:8000/v1/models >/dev/null; then
            mark_phase server_ready
            return 0
        fi
        sleep 10
    done
    tail -200 "${current_log}"
    return 1
}

run_probe() {
    local run_dir="$1"
    local phase="$2"
    local principal="$3"
    local requests="$4"
    local concurrency="$5"
    local max_tokens="$6"
    local allowed_token_id="${7:-}"
    local return_token_ids="${8:-false}"
    local cmd=(
        "${VENV_DIR}/bin/python"
        "${WORK_DIR}/paper_probe.py"
        --phase "${phase}"
        --principal "${principal}"
        --requests "${requests}"
        --concurrency "${concurrency}"
        --max-tokens "${max_tokens}"
        --api-key "${API_KEY}"
        --output "${run_dir}/${phase}.json"
    )
    if [[ -n "${allowed_token_id}" ]]; then
        cmd+=(--allowed-token-id "${allowed_token_id}")
    fi
    if [[ "${return_token_ids}" == "true" ]]; then
        cmd+=(--return-token-ids)
    fi
    mark_phase "${phase}_begin"
    "${cmd[@]}" | tee "${run_dir}/${phase}.summary.json"
    mark_phase "${phase}_end"
}

snapshot_state() {
    local run_dir="$1"
    local phase="$2"
    curl --fail --silent --show-error \
        -H 'Content-Type: application/json' \
        --data '{"method":"avep_get_acceptance_estimator_state"}' \
        http://127.0.0.1:8000/collective_rpc \
        > "${run_dir}/state_${phase}.json"
}

reset_estimator() {
    local run_dir="$1"
    curl --fail --silent --show-error \
        -H 'Content-Type: application/json' \
        --data '{"method":"avep_reset_acceptance_estimator"}' \
        http://127.0.0.1:8000/collective_rpc \
        > "${run_dir}/estimator_reset.json"
}

write_metadata() {
    local run_dir="$1"
    local run_name="$2"
    local pair_id="$3"
    local arm="$4"
    local adaptive="$5"
    local telemetry="$6"
    local token_id="$7"
    jq -n \
        --arg run_name "${run_name}" \
        --arg pair_id "${pair_id}" \
        --arg arm "${arm}" \
        --argjson adaptive "${adaptive}" \
        --argjson telemetry "${telemetry}" \
        --argjson poison_token_id "${token_id}" \
        '{
            run_name: $run_name,
            pair_id: ($pair_id | if . == "" then null else . end),
            arm: $arm,
            adaptive: $adaptive,
            telemetry: $telemetry,
            poison_token_id: $poison_token_id
        }' > "${run_dir}/metadata.json"
}

run_arm() {
    local run_name="$1"
    local pair_id="$2"
    local arm="$3"
    local adaptive="$4"
    local telemetry="$5"
    local detailed_metrics="$6"
    local token_id="$7"
    local return_token_ids="${8:-false}"
    local run_dir="${RESULT_ROOT}/${run_name}"
    if [[ -f "${run_dir}/COMPLETE" ]]; then
        printf 'Skipping complete run %s\n' "${run_name}"
        return
    fi
    mkdir -p "${run_dir}"
    write_metadata \
        "${run_dir}" "${run_name}" "${pair_id}" "${arm}" \
        "${adaptive}" "${telemetry}" "${token_id}"

    start_server "${run_dir}" "${adaptive}" "${telemetry}" "${detailed_metrics}"
    snapshot_state "${run_dir}" initial
    run_probe "${run_dir}" warmup victim 1024 32 32 "" "${return_token_ids}"
    snapshot_state "${run_dir}" warmup
    run_probe "${run_dir}" baseline victim 2048 32 32 "" "${return_token_ids}"
    snapshot_state "${run_dir}" baseline

    local intervention_token=""
    if [[ "${arm}" != "placebo" ]]; then
        intervention_token="${token_id}"
    fi
    run_probe \
        "${run_dir}" intervention attacker 1024 64 32 \
        "${intervention_token}" "${return_token_ids}"
    snapshot_state "${run_dir}" intervention

    if [[ "${arm}" == "reset" ]]; then
        reset_estimator "${run_dir}"
        snapshot_state "${run_dir}" reset
    fi

    for window_number in $(seq 1 "${POST_WINDOWS}"); do
        local window
        window="$(printf '%02d' "${window_number}")"
        run_probe \
            "${run_dir}" "post_${window}" victim 1024 32 32 "" \
            "${return_token_ids}"
        snapshot_state "${run_dir}" "post_${window}"
    done
    stop_server
    cp "${WORK_DIR}/manifest.txt" "${run_dir}/environment.txt"
    touch "${run_dir}/COMPLETE"
}

run_token_preflight() {
    local run_dir="${RESULT_ROOT}/token_preflight"
    if [[ -f "${run_dir}/COMPLETE" ]]; then
        printf 'Skipping complete token preflight.\n'
        return
    fi
    mkdir -p "${run_dir}"
    start_server "${run_dir}" true true true
    run_probe "${run_dir}" warmup victim 256 32 16 "" true
    while IFS= read -r token_id; do
        run_probe \
            "${run_dir}" "token_${token_id}" attacker 64 64 16 \
            "${token_id}" true
    done < <(
        jq -r '.ordinary_single_tokens[:6][].token_id' \
            "${WORK_DIR}/ordinary_tokens.json"
    )
    stop_server
    jq -s '
        map(select(.summary.draft_tokens > 0))
        | min_by(.summary.draft_acceptance_rate)
        | .config.allowed_token_id
    ' "${run_dir}"/token_*.json \
        | tee "${run_dir}/selected_token_id.txt"
    touch "${run_dir}/COMPLETE"
}

selected_token_id() {
    local selected="${RESULT_ROOT}/token_preflight/selected_token_id.txt"
    if [[ ! -f "${selected}" ]]; then
        printf 'Token preflight must run first.\n' >&2
        return 1
    fi
    tr -d '[:space:]' < "${selected}"
}

run_performance_pairs() {
    local token_id
    token_id="$(selected_token_id)"
    local orders=(
        'placebo attack'
        'attack placebo'
        'attack placebo'
        'placebo attack'
        'attack placebo'
        'placebo attack'
        'placebo attack'
        'attack placebo'
        'placebo attack'
        'attack placebo'
    )
    if ((PAIR_COUNT > ${#orders[@]})); then
        printf 'PAIR_COUNT is capped at %s.\n' "${#orders[@]}" >&2
        return 1
    fi
    for pair_number in $(seq 1 "${PAIR_COUNT}"); do
        local pair_id
        pair_id="$(printf '%02d' "${pair_number}")"
        for arm in ${orders[$((pair_number - 1))]}; do
            run_arm \
                "pair_${pair_id}_${arm}" "${pair_id}" "${arm}" \
                true false false "${token_id}" false
        done
    done
}

run_reset_controls() {
    local token_id
    token_id="$(selected_token_id)"
    for repetition in $(seq 1 "${RESET_REPS}"); do
        run_arm \
            "reset_$(printf '%02d' "${repetition}")" "" reset \
            true false false "${token_id}" false
    done
}

run_adaptive_off_controls() {
    local token_id
    token_id="$(selected_token_id)"
    for repetition in $(seq 1 "${ADAPTIVE_OFF_REPS}"); do
        run_arm \
            "adaptive_off_$(printf '%02d' "${repetition}")" "" adaptive_off \
            false false false "${token_id}" false
    done
}

run_mechanism_controls() {
    local token_id
    token_id="$(selected_token_id)"
    run_arm mechanism_attack "" attack true true true "${token_id}" true
    run_arm mechanism_placebo "" placebo true true true "${token_id}" true
}

analyze_results() {
    "${VENV_DIR}/bin/python" "${WORK_DIR}/analyze_paper_trials.py" \
        --result-root "${RESULT_ROOT}" \
        --output "${RESULT_ROOT}/paper_assessment.json" \
        --csv-output "${RESULT_ROOT}/paper_trials.csv" \
        | tee "${RESULT_ROOT}/paper_assessment.stdout.json"
}

mode="${1:-core}"
case "${mode}" in
    token-preflight)
        run_token_preflight
        ;;
    pairs)
        run_performance_pairs
        ;;
    controls)
        run_reset_controls
        run_adaptive_off_controls
        ;;
    mechanism)
        run_mechanism_controls
        ;;
    analyze)
        analyze_results
        ;;
    core)
        run_token_preflight
        run_performance_pairs
        run_reset_controls
        run_adaptive_off_controls
        run_mechanism_controls
        analyze_results
        ;;
    *)
        printf 'Unknown mode: %s\n' "${mode}" >&2
        exit 2
        ;;
esac
